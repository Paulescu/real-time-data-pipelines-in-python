PREFIX_SEPARATOR = b"|"
PROCESSED_OFFSET_KEY = b"__topic_offset__"
LATEST_TIMESTAMP_KEY = b"__topic_latest_timestamp__"

METADATA_CF_NAME = "__metadata__"
EXPIRED_WINDOWS_CF_NAME = "__expired_windows__"
