from typing import Any, Optional, List, Tuple, TYPE_CHECKING

from quixstreams.state.types import WindowedState

if TYPE_CHECKING:
    from .transaction import WindowedRocksDBPartitionTransaction


class WindowedTransactionState(WindowedState):
    __slots__ = ("_transaction",)

    def __init__(self, transaction: "WindowedRocksDBPartitionTransaction"):
        """
        A windowed state to be provided into `StreamingDataFrame` window functions.

        :param transaction: instance of `WindowedRocksDBPartitionTransaction`
        """
        self._transaction = transaction

    def get_window(
        self, start: float, end: float, default: Any = None
    ) -> Optional[Any]:
        """
        Get the value of the window defined by `start` and `end` timestamps
        if the window is present in the state, else default

        :param start: start of the window
        :param end: end of the window
        :param default: default value to return if the key is not found
        :return: value or None if the key is not found and `default` is not provided
        """
        return self._transaction.get_window(start=start, end=end, default=default)

    def update_window(self, start: float, end: float, value: Any, timestamp: float):
        """
        Set a value for the window.

        This method will also update the latest observed timestamp in state partition
        using the provided `timestamp`.


        :param start: start of the window
        :param end: end of the window
        :param value: value of the window
        :param timestamp: current message timestamp
        """
        return self._transaction.update_window(
            start=start, end=end, timestamp=timestamp, value=value
        )

    def get_latest_timestamp(self) -> float:
        """
        Get the latest observed timestamp for the current state partition.

        Use this timestamp to determine if the arriving event is late and should be
        discarded from the processing.

        :return: latest observed event timestamp
        """

        return self._transaction.get_latest_timestamp()

    def expire_windows(self) -> List[Tuple[Tuple[float, float], Any]]:
        """
        Get a list of expired windows from RocksDB considering the current
        latest timestamp, window duration and grace period.

        It also marks the latest found window as expired in the expiration index, so
        calling this method multiple times will yield different results for the same
        "latest timestamp".
        """
        return self._transaction.expire_windows()
