import logging
from typing import Optional

from rocksdict import ReadOptions, RdictItems

from .transaction import WindowedRocksDBPartitionTransaction
from .. import ColumnFamilyDoesNotExist
from ..metadata import (
    METADATA_CF_NAME,
    LATEST_TIMESTAMP_KEY,
)
from ..partition import (
    RocksDBStorePartition,
)
from ..serialization import float_from_double_bytes
from ..types import RocksDBOptionsType

logger = logging.getLogger(__name__)


class WindowedRocksDBStorePartition(RocksDBStorePartition):
    def __init__(
        self,
        path: str,
        duration: float,
        grace: float,
        options: Optional[RocksDBOptionsType] = None,
        open_max_retries: int = 10,
        open_retry_backoff: float = 3.0,
    ):
        super().__init__(
            path=path,
            options=options,
            open_max_retries=open_max_retries,
            open_retry_backoff=open_retry_backoff,
        )
        self._duration = duration
        self._grace = grace
        self._latest_timestamp = self._get_latest_timestamp_from_db()
        self._expiration_index_cf_name = f"__expiration-index__"
        self._ensure_column_family(self._expiration_index_cf_name)

    @property
    def duration(self) -> float:
        return self._duration

    @property
    def grace(self) -> float:
        return self._grace

    @property
    def expiration_index_cf_name(self) -> str:
        return self._expiration_index_cf_name

    def iter_items(
        self, from_key: bytes, read_opt: ReadOptions, cf_name: str = "default"
    ) -> RdictItems:
        cf = self.get_column_family(cf_name=cf_name)
        return cf.items(from_key=from_key, read_opt=read_opt)

    def begin(self) -> "WindowedRocksDBPartitionTransaction":
        return WindowedRocksDBPartitionTransaction(
            partition=self,
            dumps=self._dumps,
            loads=self._loads,
            latest_timestamp=self._latest_timestamp,
        )

    def set_latest_timestamp(self, timestamp: float):
        self._latest_timestamp = timestamp

    def _get_latest_timestamp_from_db(self) -> float:
        value = self.get(LATEST_TIMESTAMP_KEY, cf_name=METADATA_CF_NAME)
        if value is None:
            return 0.0
        return float_from_double_bytes(value)

    def _ensure_column_family(self, cf_name: str):
        try:
            self.get_column_family(cf_name)
        except ColumnFamilyDoesNotExist:
            self.create_column_family(cf_name)
