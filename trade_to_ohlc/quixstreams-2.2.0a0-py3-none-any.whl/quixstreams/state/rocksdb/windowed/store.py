from typing import Optional, cast

from .partition import WindowedRocksDBStorePartition
from .transaction import WindowedRocksDBPartitionTransaction
from ..store import RocksDBStore
from ..types import RocksDBOptionsType

# TODO: See why state hurts CPU so much


class WindowedRocksDBStore(RocksDBStore):
    def __init__(
        self,
        name: str,
        topic: str,
        base_dir: str,
        duration: float,
        grace: float = 0.0,
        options: Optional[RocksDBOptionsType] = None,
        open_max_retries: int = 10,
        open_retry_backoff: float = 3.0,
    ):
        super().__init__(
            name=name,
            topic=topic,
            base_dir=base_dir,
            options=options,
            open_max_retries=open_max_retries,
            open_retry_backoff=open_retry_backoff,
        )

        if not isinstance(duration, int):
            raise TypeError("Window size must be an integer")
        if duration < 1:
            raise ValueError("Window size cannot be smaller than 1")
        if grace < 0:
            raise ValueError("Window grace cannot be smaller than 0")
        self._duration = duration
        self._grace = grace

    def create_new_partition(self, path: str) -> WindowedRocksDBStorePartition:
        db_partition = WindowedRocksDBStorePartition(
            path=path,
            options=self._options,
            open_max_retries=self._open_max_retries,
            open_retry_backoff=self._open_retry_backoff,
            duration=self._duration,
            grace=self._grace,
        )
        return db_partition

    def assign_partition(self, partition: int) -> WindowedRocksDBStorePartition:
        return cast(
            WindowedRocksDBStorePartition, super().assign_partition(partition=partition)
        )

    def start_partition_transaction(
        self, partition: int
    ) -> WindowedRocksDBPartitionTransaction:
        return cast(
            WindowedRocksDBPartitionTransaction,
            super().start_partition_transaction(partition=partition),
        )
