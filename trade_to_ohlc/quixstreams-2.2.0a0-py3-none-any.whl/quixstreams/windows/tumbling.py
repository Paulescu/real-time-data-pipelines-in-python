from typing import Optional, TYPE_CHECKING

from quixstreams.windows.base import (
    FixedWindowDefinition,
    WindowAggregateFunc,
    WindowMergeFunc,
    FixedWindow,
)

if TYPE_CHECKING:
    from quixstreams.dataframe import StreamingDataFrame


class TumblingWindowDefinition(FixedWindowDefinition):
    def __init__(
        self,
        duration: float,
        grace: float,
        dataframe: "StreamingDataFrame",
        name: Optional[str] = None,
    ):
        super().__init__(duration=duration, grace=grace, dataframe=dataframe, name=name)

    def _get_name(self, func_name: str) -> str:
        return self._name or f"tumbling_window_{self._duration}_{func_name}"

    def _create_window(
        self,
        func_name: str,
        aggregate_func: WindowAggregateFunc,
        merge_func: Optional[WindowMergeFunc] = None,
    ) -> "TumblingWindow":
        return TumblingWindow(
            duration=self._duration,
            grace=self._grace,
            name=self._get_name(func_name=func_name),
            aggregate_func=aggregate_func,
            merge_func=merge_func,
            dataframe=self._dataframe,
        )


class TumblingWindow(FixedWindow):
    def __init__(
        self,
        duration: float,
        grace: float,
        name: str,
        aggregate_func: WindowAggregateFunc,
        dataframe: "StreamingDataFrame",
        merge_func: Optional[WindowMergeFunc] = None,
    ):
        super().__init__(
            duration=duration,
            grace=grace,
            name=name,
            aggregate_func=aggregate_func,
            merge_func=merge_func,
            dataframe=dataframe,
        )
