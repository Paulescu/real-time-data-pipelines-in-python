import functools
from abc import ABC, abstractmethod
from typing import Any, Optional, Callable, TypeVar, Tuple, List, TYPE_CHECKING, cast

from typing_extensions import TypedDict

from quixstreams.context import (
    message_context,
    message_key,
)
from quixstreams.state import (
    StateStoreManager,
    WindowedPartitionTransaction,
    WindowedState,
)

if TYPE_CHECKING:
    from quixstreams.dataframe import StreamingDataFrame


# TODO: Earliest/latest fails with IndexError if "updated" is [], which may happen
#   if the event is late and nothing has been updated
# TODO: Docstrings & comments
# TODO: Tests for final windows
# TODO: Windows should support size <1 sec.
# TODO: Windows tests use private methods - this shouldn't happen


class WindowResult(TypedDict):
    start: float
    end: float
    value: Any


T = TypeVar("T")
WindowAggregateFunc = Callable[[float, float, float, T, WindowedState], Any]
WindowMergeFunc = Callable[[Any], Any]
WindowedDataFrameFunc = Callable[
    [Any, WindowedState],
    Tuple[List[WindowResult], List[WindowResult]],
]


def _default_merge_func(state_value: Any) -> Any:
    return state_value


def _mean_merge_func(state_value: Tuple[float, int]):
    sum_, count_ = state_value
    return sum_ / count_


def get_window_ranges(
    timestamp: float, window_duration: float, step: Optional[float] = None
) -> List[Tuple[float, float]]:
    if not step:
        step = window_duration

    window_ranges = []
    current_window_start = timestamp - (timestamp % step)

    while (
        current_window_start > timestamp - window_duration and current_window_start >= 0
    ):
        window_end = current_window_start + window_duration
        window_ranges.insert(0, (current_window_start, window_end))
        current_window_start -= step

    return window_ranges


class FixedWindowDefinition(ABC):
    def __init__(
        self,
        duration: float,
        grace: float,
        dataframe: "StreamingDataFrame",
        name: Optional[str] = None,
        step: Optional[float] = None,
    ):
        self._duration = duration
        self._grace = grace
        self._dataframe = dataframe
        self._name = name
        self._step = step

        if self._duration < 0:
            raise ValueError(f"Window duration must be positive, got {self._duration}")

        if self._grace < 0:
            raise ValueError(f"Window grace must be positive, got {self._grace}")

        if self._step is not None and (self._step <= 0 or self._step >= duration):
            raise ValueError(
                f"Window step size must be smaller than duration and bigger than zero, "
                f"got {self._step}"
            )

    @abstractmethod
    def _create_window(
        self,
        func_name: str,
        aggregate_func: WindowAggregateFunc,
        merge_func: Optional[WindowMergeFunc] = None,
    ) -> "FixedWindow":
        ...

    def sum(self) -> "FixedWindow":
        """
        Configure the window to aggregate data by summing up values within each window period.

        :return: A window configured to perform sum aggregation.
        """

        def func(
            start: float,
            end: float,
            timestamp: float,
            value: Any,
            state: WindowedState,
        ):
            current_value = state.get_window(start=start, end=end, default=0)
            updated_value = current_value + value

            state.update_window(start, end, timestamp=timestamp, value=updated_value)
            return updated_value

        return self._create_window(func_name="sum", aggregate_func=func)

    def count(self) -> "FixedWindow":
        """
        Configure the window to aggregate data by counting the number of records within each window period.

        :return: A window configured to perform record count.
        """

        def func(
            start: float,
            end: float,
            timestamp: float,
            _: Any,
            state: WindowedState,
        ):
            current_value = state.get_window(start=start, end=end, default=0)
            updated_value = current_value + 1

            state.update_window(start, end, timestamp=timestamp, value=updated_value)
            return updated_value

        return self._create_window(func_name="count", aggregate_func=func)

    def mean(self) -> "FixedWindow":
        """
        Configure the window to aggregate data by calculating the mean of the values within each window period.

        :return: A window configured to calculate the mean of the data values.
        """

        def func(
            start: float,
            end: float,
            timestamp: float,
            value: Any,
            state: WindowedState,
        ):
            sum_, count_ = state.get_window(start=start, end=end, default=(0.0, 0))

            sum_ += +value
            count_ += +1
            state.update_window(start, end, timestamp=timestamp, value=(sum_, count_))
            return sum_, count_

        return self._create_window(
            func_name="mean", aggregate_func=func, merge_func=_mean_merge_func
        )

    def reduce(
        self, reducer: Callable[[Any, Any], T], initializer: Callable[[Any], T]
    ) -> "FixedWindow":
        """
        Configure the window to perform a custom aggregation using a user-provided reduce function.

        :param reducer: A function that takes two arguments (the accumulated value and a new value)
            and returns a single value. This function is used for aggregating data within the window.
        :param initializer: A function to call for every first element of the window. This function is used to
            initialize the value of the first element of the window.

        :return: A window configured to perform custom reduce aggregation on the data.
        """

        def func(
            start: float,
            end: float,
            timestamp: float,
            value: Any,
            state: WindowedState,
        ):
            current_value = state.get_window(start=start, end=end)

            if current_value is None:
                updated_value = initializer(value)
            else:
                updated_value = reducer(current_value, value)

            state.update_window(start, end, timestamp=timestamp, value=updated_value)
            return updated_value

        return self._create_window(func_name="reduce", aggregate_func=func)

    def max(self) -> "FixedWindow":
        """
        Configure the window to find the maximum value within each window period.

        :return: A window instance configured to find the maximum value within each window period.
        """

        def func(
            start: float,
            end: float,
            timestamp: float,
            value: Any,
            state: WindowedState,
        ):
            current_value = state.get_window(start=start, end=end)

            if current_value is None:
                updated_value = value
            else:
                updated_value = max(current_value, value)

            state.update_window(start, end, timestamp=timestamp, value=updated_value)
            return updated_value

        return self._create_window(func_name="max", aggregate_func=func)

    def min(self) -> "FixedWindow":
        """
        Configure the window to find the minimum value within each window period.

        :return: A window instance configured to find the minimum value within each window period.
        """

        def func(
            start: float,
            end: float,
            timestamp: float,
            value: Any,
            state: WindowedState,
        ):
            current_value = state.get_window(start=start, end=end)

            if current_value is None:
                updated_value = value
            else:
                updated_value = min(current_value, value)

            state.update_window(start, end, timestamp=timestamp, value=updated_value)
            return updated_value

        return self._create_window(func_name="min", aggregate_func=func)


class FixedWindow(ABC):
    def __init__(
        self,
        duration: float,
        grace: float,
        name: str,
        aggregate_func: WindowAggregateFunc,
        dataframe: "StreamingDataFrame",
        merge_func: Optional[WindowMergeFunc] = None,
        step: Optional[float] = None,
    ):
        self._duration = duration
        self._grace = grace
        self._name = name
        self._aggregate_func = aggregate_func
        self._merge_func = merge_func or _default_merge_func
        self._dataframe = dataframe
        self._step = step

        if self._name is None:
            # TODO: When the name can be empty?
            raise ValueError("Window name must not be empty")

    def _stale(self, window_end: float, latest_timestamp: float) -> bool:
        return latest_timestamp > window_end + self._grace

    def _process_window(
        self, value, state: WindowedState, timestamp: float
    ) -> (List[WindowResult], List[WindowResult]):
        latest_timestamp = state.get_latest_timestamp()
        ranges = get_window_ranges(
            timestamp=timestamp, window_duration=self._duration, step=self._step
        )

        updated_windows = []
        for start, end in ranges:
            # TODO: Log when the value is late and no window is updated
            if not self._stale(window_end=end, latest_timestamp=latest_timestamp):
                aggregated = self._aggregate_func(start, end, timestamp, value, state)
                updated_windows.append(
                    {
                        "start": start,
                        "end": end,
                        "value": self._merge_func(aggregated),
                    }
                )

        expired_windows = []
        for (start, end), aggregated in state.expire_windows():
            expired_windows.append(
                {"start": start, "end": end, "value": self._merge_func(aggregated)}
            )
        return updated_windows, expired_windows

    def latest(self) -> "StreamingDataFrame":
        """
        Apply the window transformation to the StreamingDataFrame to return the latest result from the latest window.

        This method processes streaming data and returns the most recent value from the latest window.
        It is useful when you need the latest aggregated result up to the current moment in a streaming data context.
        """
        return self._apply_window(
            lambda value, state, process_window=self._process_window: process_window(
                value=value,
                state=state,
                timestamp=message_context().timestamp.seconds,
            )[0][-1],
            name=self._name,
        )

    def final(self, expand: bool = True) -> "StreamingDataFrame":
        """
        Apply the window transformation to the StreamingDataFrame to return the results when a window closes.

        This method processes streaming data and returns results at the closure of each window.
        It's ideal for scenarios where you need the aggregated results after the complete data for a window is received.
        TODO: add a note about irregular message keys
        :param expand: if True, expand the returned iterable into individual values
            downstream. If returned value is not iterable, `TypeError` will be raised.
            Default - `True`
        """
        return self._apply_window(
            lambda value, state, process_window=self._process_window: process_window(
                value=value, state=state, timestamp=message_context().timestamp.seconds
            )[1],
            expand=expand,
            name=self._name,
        )

    def all(self, expand: bool = True) -> "StreamingDataFrame":
        """
        Apply the window transformation to the StreamingDataFrame to return results for each window update.

        This method processes streaming data and returns results for every update within each window,
        regardless of whether the window is closed or not.
        It's suitable for scenarios where you need continuous feedback the aggregated data throughout the window's
        duration.

        :param expand: if True, expand the returned iterable into individual values
            downstream. If returned value is not iterable, `TypeError` will be raised.
            Default - `True`.
        """
        return self._apply_window(
            lambda value, state, process_window=self._process_window: process_window(
                value=value,
                state=state,
                timestamp=message_context().timestamp.seconds,
            )[0],
            expand=expand,
            name=self._name,
        )

    def _apply_window(
        self,
        func: WindowedDataFrameFunc,
        name: str,
        expand: bool = False,
    ) -> "StreamingDataFrame":
        self._dataframe.state_manager.register_windowed_store(
            topic_name=self._dataframe.topic.name,
            store_name=name,
            duration=self._duration,
            grace=self._grace,
        )

        func = _as_window(
            func=func, state_manager=self._dataframe.state_manager, store_name=name
        )

        return self._dataframe.apply(func=func, expand=expand)


def _as_window(
    func: WindowedDataFrameFunc, state_manager: StateStoreManager, store_name: str
) -> WindowAggregateFunc:
    @functools.wraps(func)
    def wrapper(value: object) -> object:
        transaction = cast(
            WindowedPartitionTransaction,
            state_manager.get_store_transaction(store_name=store_name),
        )
        key = message_key()
        # Prefix all the state keys by the message key
        with transaction.with_prefix(prefix=key):
            # Pass a State object with an interface limited to the key updates only
            return func(value, transaction.state)

    return wrapper
