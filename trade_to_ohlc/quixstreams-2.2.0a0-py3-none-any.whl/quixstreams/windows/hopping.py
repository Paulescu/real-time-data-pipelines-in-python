from typing import Optional, TYPE_CHECKING

from quixstreams.windows.base import (
    FixedWindowDefinition,
    WindowAggregateFunc,
    FixedWindow,
    WindowMergeFunc,
)

if TYPE_CHECKING:
    from quixstreams.dataframe import StreamingDataFrame


class HoppingWindowDefinition(FixedWindowDefinition):
    def __init__(
        self,
        duration: float,
        grace: float,
        step: float,
        dataframe: "StreamingDataFrame",
        name: Optional[str] = None,
    ):
        super().__init__(
            duration=duration, grace=grace, dataframe=dataframe, name=name, step=step
        )

    def _get_name(self, func_name: str) -> str:
        return self._name or f"hopping_window_{self._duration}_{self._step}_{func_name}"

    def _create_window(
        self,
        func_name: str,
        aggregate_func: WindowAggregateFunc,
        merge_func: Optional[WindowMergeFunc] = None,
    ) -> "HoppingWindow":
        return HoppingWindow(
            duration=self._duration,
            grace=self._grace,
            step=self._step,
            name=self._get_name(func_name=func_name),
            aggregate_func=aggregate_func,
            merge_func=merge_func,
            dataframe=self._dataframe,
        )


class HoppingWindow(FixedWindow):
    def __init__(
        self,
        duration: float,
        grace: float,
        step: float,
        name: str,
        aggregate_func: WindowAggregateFunc,
        dataframe: "StreamingDataFrame",
        merge_func: Optional[WindowMergeFunc] = None,
    ):
        super().__init__(
            duration=duration,
            grace=grace,
            name=name,
            aggregate_func=aggregate_func,
            merge_func=merge_func,
            dataframe=dataframe,
            step=step,
        )
